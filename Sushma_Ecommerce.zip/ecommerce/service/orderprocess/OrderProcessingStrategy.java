package com.ecommerce.service.orderprocess;

import com.ecommerce.model.Order;

public interface OrderProcessingStrategy {
    void processOrder(Order order);
}
