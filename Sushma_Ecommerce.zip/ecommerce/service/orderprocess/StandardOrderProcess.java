package com.ecommerce.service.orderprocess;

import com.ecommerce.model.Order;

public class StandardOrderProcess implements OrderProcessingStrategy{
    public void processOrder(Order order){
        System.out.println("Processing order in standard mode for Order ID: " + order.getOrderId());
    }
}
