package com.ecommerce.service.paymentprocess;

public abstract class PaymentService {
        private double amount;

        public PaymentService(double amount) {
            this.amount = amount;
        }

        public double getAmount() {
            return amount;
        }

        public abstract void pay();

        public void paymentDetails() {
            System.out.println("Processing payment of Rs." + amount);
        }

}
