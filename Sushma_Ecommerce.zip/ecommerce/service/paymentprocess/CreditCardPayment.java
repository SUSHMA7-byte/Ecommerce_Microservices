package com.ecommerce.service.paymentprocess;

public class CreditCardPayment extends PaymentService {

        private String cardNumber;

        public CreditCardPayment(double amount, String cardNumber) {
            super(amount);
            this.cardNumber = cardNumber;
        }

        @Override
        public void pay() {
            System.out.println("Paying Rs." + getAmount() + " using Credit Card: " + cardNumber);
        }
    }