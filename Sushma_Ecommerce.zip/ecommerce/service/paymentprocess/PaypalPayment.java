package com.ecommerce.service.paymentprocess;

public class PaypalPayment extends PaymentService {

        private String email;

        public PaypalPayment(double amount, String email) {
            super(amount);
            this.email = email;
        }

        @Override
        public void pay() {
            System.out.println("Paying Rs." + getAmount() + " using PayPal: " + email);
        }
    }
