package com.ecommerce.main;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import com.ecommerce.model.*;
import com.ecommerce.service.dummy.CartService;
import com.ecommerce.service.dummy.CreditCardPayment;
import com.ecommerce.service.dummy.PaymentService;
import com.ecommerce.service.order.OrderService;
import com.ecommerce.service.order.OrdersImplementation;
import com.ecommerce.service.paymentprocess.PaymentGateway;
import com.ecommerce.service.paymentprocess.PaymentMethod;
import com.ecommerce.service.paymentprocess.PaymentRepository;
import com.ecommerce.service.user.UserServiceImpl;
import com.ecommerce.service.user.UserServiceInterface;
import com.ecommerce.model.Product;
import com.ecommerce.service.orderprocessvalidator.*;
import com.ecommerce.exception.*;

public class EcommerceApp {
    public static void main(String[] args) throws PaymentFailedException {
        UserServiceInterface user = new UserServiceImpl();
        OrdersImplementation displayOrder = new OrdersImplementation(user);
        Scanner sc = new Scanner(System.in);

        Order currentOrder = null;
        int choice;

        do {
            System.out.println("\n--- E-COMMERCE MENU ---");
            System.out.println("1. View Products");
            System.out.println("2. Add to Cart");
            System.out.println("3. Remove from Cart");
            System.out.println("4. View Cart");
            System.out.println("5. Checkout");
            System.out.println("6. Place Order");
            System.out.println("7. View Popular Searches");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            OrderProcessingStrategy processingStrategy;
			switch (choice) {
            case 1:
                System.out.println("\nAvailable Products :");
                ArrayList<Product> dbProducts = (ArrayList<Product>) user.getProductsFromDB();
                for (Product product : dbProducts) {
                    System.out.println("ID: " + product.getProductId() +
                            ", Name: " + product.getProductName() +
                            ", Price: ₹" + product.getPrice() +
                            ", Description: " + product.getDescription() +
                            ", Category: " + product.getCategory().getCategoryName());
                }
                break;

                case 2:
                    System.out.print("Enter Product ID to add: ");
                    int addId = sc.nextInt();
                    System.out.print("Enter Quantity: ");
                    int qty = sc.nextInt();
                    user.addToCart(addId, qty);
                    break;

                case 3:
                	System.out.println("\nItems in your cart:");
                    List<Product> productList = user.getProductsFromDB();
                    Map<Integer, Integer> cartItems = user.viewCart();

                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cognizant", "root", "Prassu@2208");
                             Statement stmt = con.createStatement();
                             ResultSet rs = stmt.executeQuery("SELECT Product_id, Product_name, quantity FROM Cart")) {

                            boolean empty = true;
                            while (rs.next()) {
                                empty = false;
                                System.out.println("ID: " + rs.getInt(1) + ", Name: " + rs.getString(2) +
                                        ", Quantity: " + rs.getInt(3));
                            }

                            if (empty) {
                                System.out.println("Cart is empty.");
                                break;
                            }

                            System.out.print("Enter Product ID to remove: ");
                            int removeId = sc.nextInt();
                            System.out.print("Enter Quantity to remove: ");
                            int removeQty = sc.nextInt();

                            user.removeFromCart(removeId, removeQty);

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case 4:
                    System.out.println("\nYour Cart Details:");

                    try {

                        String url = "jdbc:mysql://localhost:3306/cognizant";
                        String dbUser="root";
                        String dbPass = "Prassu@2208";

                        Class.forName("com.mysql.cj.jdbc.Driver");

                        Connection con = DriverManager.getConnection(url, dbUser, dbPass);

                        Statement st = con.createStatement();

                        String query = "SELECT * FROM Cart";
                        ResultSet result = st.executeQuery(query);

                        boolean isEmpty = true;
                        double totalAmount = 0.0;

                        while (result.next()) {
                            isEmpty = false;
                            int productId = result.getInt(1);
                            String productName = result.getString(2);
                            int quantity = result.getInt(3);
                            double price = result.getDouble(4);
                            double subTotal = price * quantity;
                            totalAmount += subTotal;

                            System.out.println("Product ID: " + productId +
                                               ", Name: " + productName +
                                               ", Quantity: " + quantity +
                                               ", Price per Item: ₹" + price +
                                               ", Subtotal: ₹" + subTotal);
                        }

                        if (isEmpty) {
                            System.out.println("Cart is empty.");
                        } else {
                            System.out.println("Total Cart Value: ₹" + totalAmount);
                        }
           
                        result.close();
                        st.close();
                        con.close();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case 5:
                    Scanner scanner = new Scanner(System.in);
                    int userId = 101;

                    CartService cartService = new CartService();
                    UserServiceImpl userService = new UserServiceImpl();
                    List<Product> productList1 = userService.getProductsFromDB();
                    OrderService orderService = new OrderService();
                    PaymentRepository paymentRepo = new PaymentRepository();

                    Map<Integer, Integer> cartItems1 = cartService.getCartItemsFromDB();

                    if (cartItems1 == null || cartItems1.isEmpty()) {
                        System.out.println("Cart is empty. Add products before checkout.");
                        break;
                    }

                    Customer customer = new Customer(101, "Sushma", "sushma@mail.com", "Bangalore", "9999999999");

                    Map<Integer, Product> productMap = new HashMap<>();
                    for (Product p : productList1) {
                        productMap.put(p.getProductId(), p);
                    }

                    List<OrderItem> orderItems = new ArrayList<>();

                    for (Map.Entry<Integer, Integer> entry : cartItems1.entrySet()) {
                        int productId = entry.getKey();
                        int quantity = entry.getValue();

                        if (quantity <= 0) {
                            System.out.println("Skipping Product ID " + productId + " due to invalid quantity: " + quantity);
                            continue;
                        }

                        Product product = productMap.get(productId);
                        if (product != null) {
                            OrderItem item = new OrderItem("ITM" + productId, product, quantity);
                            try {
                                OrderValidator.validateOrderItem(item);
                                orderItems.add(item);
                            } catch (InvalidOrderException e) {
                                System.out.println("Validation Error: " + e.getMessage());
                            }
                        }
                    }

                    if (orderItems.isEmpty()) {
                        System.out.println("No valid items in order to proceed with checkout.");
                        break;
                    }

                    double totalAmount = 0.0;
                    for (OrderItem item : orderItems) {
                        totalAmount += item.getPrice();
                    }

                    double discount = 0.0;
                    if (totalAmount > 50000) {
                        discount = totalAmount * 0.10;
                    } else if (totalAmount >= 20000) {
                        discount = totalAmount * 0.05;
                    }

                    double finalAmount = totalAmount - discount;

                    System.out.println("\nTotal: ₹" + totalAmount);
                    System.out.println("Discount: ₹" + discount);
                    System.out.println("Amount Payable: ₹" + finalAmount);

                    PaymentMethod paymentMethod = PaymentGateway.selectPaymentMethod(scanner);
                    if (paymentMethod != null) {
                        paymentMethod.collectPaymentDetails(scanner);
                        paymentMethod.processPayment();
                    } else {
                        System.out.println("Invalid payment method selected.");
                        break;
                    }

                    System.out.println("Choose Order Type: 1 for Standard, any other number for Priority:");
                    int orderType = scanner.nextInt();
                    scanner.nextLine(); // consume newline

                    
                    if (orderType == 1) {
                        processingStrategy = new StandardOrderProcess();
                    } else {
                        processingStrategy = new PriorityOrderProcessing();
                    }

                    String orderId = orderService.insertOrder(userId, finalAmount);
                    System.out.println("Order ID: " + orderId + " generated and saved successfully.");

                    Order order = new Order(orderId, customer, "Pending");
                    order.setProcessingStrategy(processingStrategy);

                    for (OrderItem item : orderItems) {
                        order.getItems().add(item);
                    }

                    String methodName = paymentMethod.getMethodName();
                    paymentRepo.insertPayment(orderId, finalAmount, "Successful", methodName);
                    System.out.println("Payment recorded successfully.");

                    cartService.clearCart();

                    currentOrder = order;
                    order.processOrder();

                    break;

                case 6:
                    displayOrder.displayOrderSummary(currentOrder);
                    break;

                case 7:
                    System.out.println("\nPopular Searches:");
                    List<String> searches = UserServiceInterface.getPopularSearches();
                    for (String prod : searches) {
                        System.out.println(prod);
                    }
                    break;

                case 8:
                    System.out.println("Exiting... Thank you for shopping with us!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 8);

        sc.close();
    }

	private static List<Product> getProductsFromDB() {
		// TODO Auto-generated method stub
		return null;
	}
}
