package com.ecommerce.service.order;

import com.ecommerce.util.DBConnection;
import java.sql.*;

public class OrderService {

    public String insertOrder(int userId, double totalAmount) {
        String orderId = "ORD" + System.currentTimeMillis();
        String query = "INSERT INTO Orders (order_id, user_id, order_date, total_amount, status) " +
                       "VALUES (?, ?, NOW(), ?, 'Pending')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, orderId);
            pstmt.setInt(2, userId);
            pstmt.setDouble(3, totalAmount);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderId;
    }
}
