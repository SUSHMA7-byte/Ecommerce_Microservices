package com.ecommerce.service.order;

import com.ecommerce.model.Order;

public interface OrdersInterface {
    void displayOrderSummary(Order order);
}
