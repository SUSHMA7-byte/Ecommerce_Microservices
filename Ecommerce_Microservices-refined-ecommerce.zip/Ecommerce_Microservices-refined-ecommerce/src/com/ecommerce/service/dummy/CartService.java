package com.ecommerce.service.dummy;

import com.ecommerce.util.DBConnection;
import java.sql.*;
import java.util.*;

public class CartService {

    public Map<Integer, Integer> getCartItemsFromDB() {
        Map<Integer, Integer> cartItems = new HashMap<>();
        String query = "SELECT product_id, quantity FROM Cart ";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                cartItems.put(rs.getInt("product_id"), rs.getInt("quantity"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cartItems;
    }

    public void clearCart() {
        String query = "DELETE FROM Cart ";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.executeUpdate();
            System.out.println("Cart cleared ");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
