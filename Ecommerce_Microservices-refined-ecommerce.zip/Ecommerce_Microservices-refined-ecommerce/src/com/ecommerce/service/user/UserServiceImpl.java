package com.ecommerce.service.user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

import com.ecommerce.model.Category;
import com.ecommerce.model.Product;
import com.ecommerce.service.user.UserServiceInterface;

public class UserServiceImpl implements UserServiceInterface {
    private List<Product> products = new ArrayList<>();
    private Map<Integer, Integer> cart = new HashMap<>();

    private static final String URL = "jdbc:mysql://localhost:3306/cognizant";
    private static final String USER = "root";
    private static final String PASS = "Prassu@2208";

    private Map<String, Category> categories = new HashMap<>();

    private void loadCategories() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(URL, USER, PASS);
            Statement st = con.createStatement();
            String query = "SELECT * FROM Categories";
            ResultSet result = st.executeQuery(query);

            while (result.next()) {
                String categoryId = result.getString(1);
                String categoryName = result.getString(2);
                String description = result.getString(3);

                Category category = new Category(categoryId, categoryName, description);
                categories.put(categoryId, category);
            }

            result.close();
            st.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<Product> getProductsFromDB() {
        List<Product> dbProducts = new ArrayList<>();

        loadCategories();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(URL, USER, PASS);
            Statement st = con.createStatement();
            String query = "SELECT * FROM Products";
            ResultSet result = st.executeQuery(query);

            while (result.next()) {
                int id = result.getInt(1);
                String name = result.getString(2);
                String desc = result.getString(3);
                double price = result.getDouble(4);
                String categoryId = result.getString(5);


                Category category = categories.getOrDefault(categoryId, new Category());

                Product product = new Product(id, name, price, desc, category);
                dbProducts.add(product);
            }

            result.close();
            st.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dbProducts;
    }



    @Override
    public void addToCart(int productId, int quantity) {
	    String selectProductQuery = "SELECT * FROM Products WHERE product_ID  = ?";
	    String selectCartQuery = "SELECT * FROM Cart WHERE Product_id = ?";
	    String updateCartQuery = "UPDATE Cart SET quantity = ?, price = ? WHERE Product_id = ?";
	    String insertCartQuery = "INSERT INTO Cart (Product_id, Product_name, quantity, price) VALUES (?, ?, ?, ?)";

	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
	             PreparedStatement selectProductStmt = con.prepareStatement(selectProductQuery);
	             PreparedStatement selectCartStmt = con.prepareStatement(selectCartQuery);
	             PreparedStatement updateCartStmt = con.prepareStatement(updateCartQuery);
	             PreparedStatement insertCartStmt = con.prepareStatement(insertCartQuery)) {

	            selectProductStmt.setInt(1, productId);
	            ResultSet productResult = selectProductStmt.executeQuery();

	            if (productResult.next()) {
	                String name = productResult.getString(2);
	                double price = productResult.getDouble(4);

	                selectCartStmt.setInt(1, productId);
	                ResultSet cartResult = selectCartStmt.executeQuery();

	                if (cartResult.next()) {

	                    int existingQty = cartResult.getInt(3);
	                    int newQty = existingQty + quantity;
	                    double newTotal = newQty * price;

	                    updateCartStmt.setInt(1, newQty);
	                    updateCartStmt.setDouble(2, newTotal);
	                    updateCartStmt.setInt(3, productId);
	                    updateCartStmt.executeUpdate();

	                    System.out.println("Updated cart: Product ID " + productId + ", New Quantity = " + newQty);
	                } else {

	                    double totalPrice = price * quantity;

	                    insertCartStmt.setInt(1, productId);
	                    insertCartStmt.setString(2, name);
	                    insertCartStmt.setInt(3, quantity);
	                    insertCartStmt.setDouble(4, totalPrice);
	                    insertCartStmt.executeUpdate();

	                    System.out.println("Added new item to cart: Product ID " + productId);
	                }

	            } else {
	                System.out.println("Product ID not found in products table.");
	            }

	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}


    public void removeFromCart(int productId, int quantityToRemove) {
	    String selectCartQuery = "SELECT quantity FROM Cart WHERE product_id = ?";
	    String getPriceQuery = "SELECT price FROM Products WHERE Product_Id = ?";
	    String updateCartQuery = "UPDATE Cart SET quantity = ?, price = ? WHERE Product_id = ?";
	    String deleteCartQuery = "DELETE FROM Cart WHERE product_id = ?";

	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");

	        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
	             PreparedStatement selectCartStmt = con.prepareStatement(selectCartQuery);
	             PreparedStatement getPriceStmt = con.prepareStatement(getPriceQuery);
	             PreparedStatement updateCartStmt = con.prepareStatement(updateCartQuery);
	             PreparedStatement deleteCartStmt = con.prepareStatement(deleteCartQuery)) {


	            selectCartStmt.setInt(1, productId);
	            ResultSet cartResult = selectCartStmt.executeQuery();

	            if (!cartResult.next()) {
	                System.out.println("Product ID not found in cart.");
	                return;
	            }

	            int currentQty = cartResult.getInt("quantity");

	            if (quantityToRemove >= currentQty) {
	 
	                deleteCartStmt.setInt(1, productId);
	                deleteCartStmt.executeUpdate();
	                System.out.println("Product removed completely from cart.");
	            } else {
	            
	                int newQty = currentQty - quantityToRemove;
	                getPriceStmt.setInt(1, productId);
	                ResultSet priceResult = getPriceStmt.executeQuery();

	                if (!priceResult.next()) {
	                    System.out.println("Price not found for product.");
	                    return;
	                }

	                double unitPrice = priceResult.getDouble("price");
	                double newTotal = unitPrice * newQty;

	                updateCartStmt.setInt(1, newQty);
	                updateCartStmt.setDouble(2, newTotal);
	                updateCartStmt.setInt(3, productId);
	                updateCartStmt.executeUpdate();

	                System.out.println("Updated cart: Product ID " + productId + ", New Quantity = " + newQty);
	            }

	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

    @Override
    public Map<Integer, Integer> viewCart() {
        return cart;
    }


    /* @Override
    public void printCartSummary(Map<String, Integer> summary) {
        if (summary.isEmpty()) {
            System.out.println("Cart is empty.");
        } else {
            for (Map.Entry<String, Integer> entry : summary.entrySet()) {
                System.out.println("Product: " + entry.getKey() + ", Quantity: " + entry.getValue());
            }
        }
    } */
}
