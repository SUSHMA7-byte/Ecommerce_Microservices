package com.ecommerce.service.paymentprocess;

import com.ecommerce.util.DBConnection;
import java.sql.*;

public class PaymentRepository {

	public void insertPayment(String orderId, double amount, String status, String method) {
	    String paymentId = "PAY" + System.currentTimeMillis();
	    String query = "INSERT INTO Payments (payment_id, order_id, payment_date, amount, status, payment_method) " +
	                   "VALUES (?, ?, NOW(), ?, ?, ?)";
	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(query)) {
	        pstmt.setString(1, paymentId);
	        pstmt.setString(2, orderId);
	        pstmt.setDouble(3, amount);
	        pstmt.setString(4, status);
	        pstmt.setString(5, method);
	        pstmt.executeUpdate();
	        System.out.println("Payment record inserted successfully with method: " + method);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
}
