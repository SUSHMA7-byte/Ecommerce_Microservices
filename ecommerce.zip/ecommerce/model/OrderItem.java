package com.ecommerce.model;

public class OrderItem {

    private String orderItemId;
    private Product product;
    private int quantity;
    private double price;

    public OrderItem(String orderItemId, Product product, int quantity) {
        this.orderItemId = orderItemId;
        this.product = product;
        this.quantity = quantity;
        this.price = product.getPrice() * quantity;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity(){
        return quantity;
    }
}
