package com.ecommerce.service.paymentprocess;

import com.ecommerce.exception.PaymentFailedException;

import java.util.List;

public abstract class PaymentService {
    private double amount;
    private String methodName;

    public PaymentService(double amount, String methodName) throws PaymentFailedException {
        if (amount <= 0) {
            throw new PaymentFailedException("Amount must be greater than zero.");
        }
        this.amount = amount;
        this.methodName = methodName;
    }

    public double getAmount() {
        return amount;
    }

    public String getMethodName() {
        return methodName;
    }

    public void paymentDetails() {
        System.out.println("Initiating payment of Rs." + amount +" using "+ methodName);
    }

    public abstract void pay();

    /*public static void validate(String method, double amount) throws PaymentFailedException {
        if (amount <= 0) throw new PaymentFailedException("Amount must be > 0");
        List<String> allowedMethods = List.of("CreditCard", "Paypal");
        if (!allowedMethods.contains(method)) throw new PaymentFailedException("Unsupported method");
    }*/
}
