package com.cognizant.Interfaceimpl;

import com.cognizant.Interface.Products_Interface;

public class Products_Impl implements Products_Interface {
	
	

}
