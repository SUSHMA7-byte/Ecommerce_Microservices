package com.cognizant.Interfaceimpl;

import com.cognizant.Interface.Orders_Interface;

public class Orders_Impl implements Orders_Interface {
	
	
}
