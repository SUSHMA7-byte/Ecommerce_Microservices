package ecommerce.model;

import ecommerce.exception.PaymentFailedException;

public class Payment {
    private String method;
    private double amount;

    public Payment(String method, double amount) {
        this.method = method;
        this.amount = amount;
    }

    public void processPayment() throws PaymentFailedException {
        if (amount <= 0) {
            throw new PaymentFailedException("Payment amount must be greater than zero.");
        }

        if (!method.equalsIgnoreCase("CreditCard") &&
            !method.equalsIgnoreCase("UPI") &&
            !method.equalsIgnoreCase("NetBanking")) {
            throw new PaymentFailedException("Unsupported payment method: " + method);
        }

        // Simulated payment success
        System.out.println("Payment of ₹" + amount + " using " + method + " processed successfully.");
    }

    // Optional Getters & Setters
    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
