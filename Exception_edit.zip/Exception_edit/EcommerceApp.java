package com.ecommerce.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.ecommerce.exception.InvalidOrderException;
import com.ecommerce.model.*;
import com.ecommerce.service.orderprocess.PriorityOrderProcessing;
import com.ecommerce.service.orderprocess.StandardOrderProcess;
import com.ecommerce.service.paymentprocess.CreditCardPayment;
import com.ecommerce.service.paymentprocess.PaymentService;
import com.ecommerce.service.orderprocess.OrderValidator;

public class EcommerceApp {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);

            
            Category electronics = new Category("C101", "Electronics", "Devices");
            Product laptop = new Product(1, "Dell Laptop", 59800.0, "i5, 8GB RAM", electronics);
            Customer customer = new Customer(101, "Sushma", "sushma@mail.com", "Bangalore", "9999999999");
            Order order = new Order("ORD001", customer, "Pending");
            OrderItem item = new OrderItem("ITM001", laptop, 2);

           
            OrderValidator.validateCustomer(customer);
            OrderValidator.validateProduct(laptop);
            OrderValidator.validateOrderItem(item);

           
            order.getItems().add(item);

            
            System.out.println("Customer: " + order.getCustomer().getUserName());
            System.out.println("Order ID: " + order.getOrderId());
            System.out.println("Total Amount: Rs." + item.getPrice());
            System.out.println("Order Status: " + order.getStatus());

            
            PaymentService payment = new CreditCardPayment(item.getPrice(), "1234-5678-9876-5432");
            payment.paymentDetails();
            payment.pay();

            
            System.out.println("What type of order you have placed? Press '1' if it is a Standard Order else press any number.");
            int value = sc.nextInt();
            if (value == 1) {
                order.setProcessingStrategy(new StandardOrderProcess());
                order.processOrder();
            } else {
                order.setProcessingStrategy(new PriorityOrderProcessing());
                order.processOrder();
            }

            sc.close(); 
        }

        
        catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number.");
        } 
        catch (InvalidOrderException e) {
            System.out.println("Validation Error: " + e.getMessage());
        } 
        catch (IllegalArgumentException e) {
            System.out.println("Illegal Argument: " + e.getMessage());
        } 
        catch (NullPointerException e) {
            System.out.println("Null value encountered. Please check object initialization.");
        } 
        catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }
}